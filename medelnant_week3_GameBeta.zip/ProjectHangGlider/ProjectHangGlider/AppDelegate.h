//
//  AppDelegate.h
//  ProjectHangGlider
//
//  Michael Edelnant
//  Mobile Game Design Term 1501
//  Week 3 - Game Beta
//
//  Created by vAesthetic on 1/8/15.
//  Copyright (c) 2015 medelnant. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end

